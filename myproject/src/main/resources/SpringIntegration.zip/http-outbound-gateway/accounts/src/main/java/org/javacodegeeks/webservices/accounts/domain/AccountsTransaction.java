package org.javacodegeeks.webservices.accounts.domain;

public class AccountsTransaction {
	String description = "";
	Double amount = 0.0;
	
	public String getDescription() {
		return description;
	}
	
	public Double getAmount() {
		return amount;
	}
}
