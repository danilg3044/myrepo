package com.javasampleapproach.springintegration.inbound;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ImportResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@RunWith(SpringRunner.class)
@ImportResource({"classpath:http-inbound-adapter.xml", "classpath:http-inbound-gateway.xml"})
@SpringBootTest
public class SpringIntegrationInboundComponentApplicationTests {

	private MockMvc mvc;
	
	@Autowired
	private WebApplicationContext context;
	
	@Before
    public void setUp() {
		mvc = MockMvcBuilders.webAppContextSetup(context).build();
    }

	@Test
	public void testGetAll() throws Exception {
		MockHttpServletResponse response = mvc.perform(get("/getall").contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON)).andReturn().getResponse();
		
		assertEquals(response.getStatus(), HttpStatus.OK.value());
		assertEquals(response.getContentAsString(), "[{\"id\":1,\"name\":\"Jack\",\"age\":20},{\"id\":2,\"name\":\"Peter\",\"age\":30}]");
	}
	
	@Test
	public void testCustomer() throws Exception {
		MockHttpServletResponse response = mvc.perform(post("/customer").contentType(MediaType.APPLICATION_JSON).content("{\n" + 
				"    \"id\": 1,\n" + 
				"    \"name\": \"Jack\",\n" + 
				"    \"age\": 20\n" + 
				"}")
				.accept(MediaType.APPLICATION_JSON)).andReturn().getResponse();
		
		assertEquals(response.getStatus(), HttpStatus.NO_CONTENT.value());
		assertEquals(response.getContentAsString(), "");
	}
}
